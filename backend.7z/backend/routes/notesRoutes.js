const express = require('express');
const router = express.Router();
const auth = require('../middleware/authMiddleware');
const notesController = require('../controllers/notesController');

// @route   POST /api/notes
// @desc    Create a new note
// @access  Private
router.post('/', auth, notesController.createNote);

// @route   GET /api/notes
// @desc    Get all notes for a user
// @access  Private
router.get('/', auth, notesController.getNotes);

// @route   PUT /api/notes/:id
// @desc    Update a note
// @access  Private
router.put('/:id', auth, notesController.updateNote);

// @route   DELETE /api/notes/:id
// @desc    Delete a note
// @access  Private
router.delete('/:id', auth, notesController.deleteNote);

module.exports = router;